﻿using Microsoft.Maui.Controls;

namespace projekt
{
    public partial class UserPanelPage : ContentPage
    {
        public UserPanelPage()
        {
            InitializeComponent();
        }
    }
}

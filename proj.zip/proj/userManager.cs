﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt
{
    public static class userManager
    {
        public static List<User> ListaUzytkownikow = new List<User>();

        public static void AddUser(User user)
        {
            ListaUzytkownikow.Add(user);
        }
        public static User GetUserByEmail(string email)
        {
            return ListaUzytkownikow.FirstOrDefault(u => u.Email == email);
        }
    }
}

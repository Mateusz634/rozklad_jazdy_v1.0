﻿using Microsoft.Maui.Controls;

namespace projekt
{
    public partial class registerPage : ContentPage
    {
        public registerPage()
        {
            InitializeComponent();
        }

        // Metoda wywoływana po kliknięciu ikony strzałki
        private async void OnBackButtonClicked(object sender, EventArgs e)
        {
            // Cofamy użytkownika do poprzedniej strony
            await Navigation.PopAsync();
        }

        private void OnRegisterUPButtonClicked(object sender, EventArgs e)
        {
            string name = NameEntry.Text;
            string surname = SurnameEntry.Text;
            string email = emailEntry.Text;
            string password = PasswordEntry.Text;
            string adminPassword = PermissionEntry.Text;

            User newUser = new User(name, surname, email, password, adminPassword);

            userManager.AddUser(newUser);

            NameEntry.Text = string.Empty;
            SurnameEntry.Text = string.Empty;
            emailEntry.Text = string.Empty;
            PasswordEntry.Text = string.Empty;
            PermissionEntry.Text = string.Empty;
        }

    }
}






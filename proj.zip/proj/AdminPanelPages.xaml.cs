﻿using Microsoft.Maui.Controls;

namespace projekt
{
    public partial class AdminPanelPage : ContentPage
    {
        public AdminPanelPage()
        {
            InitializeComponent();
        }
    }
}

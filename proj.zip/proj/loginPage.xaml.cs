﻿using Microsoft.Maui.Controls;

namespace projekt
{
    public partial class loginPage : ContentPage
    {
        public loginPage()
        {
            InitializeComponent();
        }

        // Metoda wywoływana po kliknięciu ikony strzałki
        private async void OnBackButtonClicked(object sender, EventArgs e)
        {
            // Cofamy użytkownika do poprzedniej strony
            await Navigation.PopAsync();
        }

        private async void OnLoginButtonClicked(object sender, EventArgs e)
        {
            // Pobierz dane z pól Entry
            string email = emailEntry.Text;
            string password = passwordEntry.Text;

            // Sprawdź, czy lista użytkowników nie jest pusta
            var user = userManager.ListaUzytkownikow.FirstOrDefault(u => u.Email == email && u.Haslo == password);

            // Jeśli użytkownik został znaleziony
            if (user != null)
            {
                // Przejdź do odpowiedniej strony w zależności od uprawnień
                if (user.Uprawnienia == "admin")
                {
                    // Jeśli to admin, przejdź do panelu administratora
                    await Navigation.PushAsync(new AdminPanelPage());
                }
                else
                {
                    // Jeśli to użytkownik, przejdź do panelu użytkownika
                    await Navigation.PushAsync(new UserPanelPage());
                }
            }
            else
            {
                // Jeśli nie znaleziono użytkownika, wyświetl błąd
                ErrorLabel.Text = "Niepoprawny e-mail lub hasło!";
            }
        }

    }
}





